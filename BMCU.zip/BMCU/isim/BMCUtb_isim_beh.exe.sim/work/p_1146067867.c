/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;



int work_p_1146067867_sub_4021871946_2955484629(char *t1, char *t2, char *t3)
{
    char t4[248];
    char t5[24];
    char t9[8];
    char t15[8];
    int t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t16;
    char *t17;
    char *t18;
    unsigned char t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    int t24;
    unsigned char t25;
    char *t26;
    int t27;
    char *t28;
    int t29;
    int t30;
    int t31;
    char *t32;
    int t33;
    char *t34;
    int t35;
    int t36;
    unsigned int t37;
    char *t38;
    int t39;
    unsigned int t40;
    unsigned int t41;
    char *t42;
    unsigned char t43;
    unsigned char t44;
    char *t45;
    char *t46;
    int t47;
    char *t48;
    int t49;
    int t50;
    int t51;
    char *t52;

LAB0:    t6 = (t4 + 4U);
    t7 = ((STD_STANDARD) + 384);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    *((int *)t9) = 0;
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 4U;
    t12 = (t4 + 124U);
    t13 = ((STD_STANDARD) + 384);
    t14 = (t12 + 88U);
    *((char **)t14) = t13;
    t16 = (t12 + 56U);
    *((char **)t16) = t15;
    *((int *)t15) = 0;
    t17 = (t12 + 80U);
    *((unsigned int *)t17) = 4U;
    t18 = (t5 + 4U);
    t19 = (t2 != 0);
    if (t19 == 1)
        goto LAB3;

LAB2:    t20 = (t5 + 12U);
    *((char **)t20) = t3;
    t21 = (t3 + 4U);
    t22 = *((int *)t21);
    t23 = (t3 + 0U);
    t24 = *((int *)t23);
    t25 = (t22 <= t24);
    if (t25 != 0)
        goto LAB4;

LAB6:    t7 = (t3 + 0U);
    t22 = *((int *)t7);
    t8 = (t3 + 4U);
    t24 = *((int *)t8);
    t27 = t24;
    t29 = t22;

LAB15:    if (t27 >= t29)
        goto LAB16;

LAB18:
LAB5:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t22 = *((int *)t8);
    t0 = t22;

LAB1:    return t0;
LAB3:    *((char **)t18) = t2;
    goto LAB2;

LAB4:    t26 = (t3 + 0U);
    t27 = *((int *)t26);
    t28 = (t3 + 4U);
    t29 = *((int *)t28);
    t30 = t29;
    t31 = t27;

LAB7:    if (t30 <= t31)
        goto LAB8;

LAB10:    goto LAB5;

LAB8:    t32 = (t3 + 0U);
    t33 = *((int *)t32);
    t34 = (t3 + 8U);
    t35 = *((int *)t34);
    t36 = (t30 - t33);
    t37 = (t36 * t35);
    t38 = (t3 + 4U);
    t39 = *((int *)t38);
    xsi_vhdl_check_range_of_index(t33, t39, t35, t30);
    t40 = (1U * t37);
    t41 = (0 + t40);
    t42 = (t2 + t41);
    t43 = *((unsigned char *)t42);
    t44 = (t43 == (unsigned char)1);
    if (t44 != 0)
        goto LAB11;

LAB13:
LAB12:    t7 = (t12 + 56U);
    t8 = *((char **)t7);
    t22 = *((int *)t8);
    t24 = (t22 + 1);
    t7 = (t12 + 56U);
    t10 = *((char **)t7);
    t7 = (t10 + 0);
    *((int *)t7) = t24;

LAB9:    if (t30 == t31)
        goto LAB10;

LAB14:    t22 = (t30 + 1);
    t30 = t22;
    goto LAB7;

LAB11:    t45 = (t6 + 56U);
    t46 = *((char **)t45);
    t47 = *((int *)t46);
    t45 = (t12 + 56U);
    t48 = *((char **)t45);
    t49 = *((int *)t48);
    t50 = xsi_vhdl_pow(2, t49);
    t51 = (t47 + t50);
    t45 = (t6 + 56U);
    t52 = *((char **)t45);
    t45 = (t52 + 0);
    *((int *)t45) = t51;
    goto LAB12;

LAB16:    t10 = (t3 + 0U);
    t30 = *((int *)t10);
    t11 = (t3 + 8U);
    t31 = *((int *)t11);
    t33 = (t27 - t30);
    t37 = (t33 * t31);
    t13 = (t3 + 4U);
    t35 = *((int *)t13);
    xsi_vhdl_check_range_of_index(t30, t35, t31, t27);
    t40 = (1U * t37);
    t41 = (0 + t40);
    t14 = (t2 + t41);
    t19 = *((unsigned char *)t14);
    t25 = (t19 == (unsigned char)1);
    if (t25 != 0)
        goto LAB19;

LAB21:
LAB20:    t7 = (t12 + 56U);
    t8 = *((char **)t7);
    t22 = *((int *)t8);
    t24 = (t22 + 1);
    t7 = (t12 + 56U);
    t10 = *((char **)t7);
    t7 = (t10 + 0);
    *((int *)t7) = t24;

LAB17:    if (t27 == t29)
        goto LAB18;

LAB22:    t22 = (t27 + -1);
    t27 = t22;
    goto LAB15;

LAB19:    t16 = (t6 + 56U);
    t17 = *((char **)t16);
    t36 = *((int *)t17);
    t16 = (t12 + 56U);
    t21 = *((char **)t16);
    t39 = *((int *)t21);
    t47 = xsi_vhdl_pow(2, t39);
    t49 = (t36 + t47);
    t16 = (t6 + 56U);
    t23 = *((char **)t16);
    t16 = (t23 + 0);
    *((int *)t16) = t49;
    goto LAB20;

LAB23:;
}

char *work_p_1146067867_sub_3335567602_2955484629(char *t1, char *t2, char *t3, char *t4)
{
    char t5[248];
    char t6[24];
    char t10[8];
    char t15[16];
    char *t0;
    char *t7;
    char *t8;
    char *t9;
    char *t11;
    char *t12;
    char *t13;
    unsigned int t14;
    char *t16;
    int t17;
    char *t18;
    int t19;
    char *t20;
    int t21;
    char *t22;
    char *t23;
    int t24;
    unsigned int t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    char *t34;
    char *t35;
    int t36;
    char *t37;
    int t38;
    unsigned char t39;
    char *t40;
    int t41;
    char *t42;
    int t43;
    int t44;
    int t45;
    char *t46;
    char *t47;
    unsigned char t48;
    unsigned char t49;
    int t50;
    char *t51;
    int t52;
    int t53;
    char *t54;
    int t55;
    unsigned int t56;
    unsigned int t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;
    char *t61;
    char *t62;
    int t63;
    char *t64;
    int t65;
    int t66;
    unsigned int t67;
    char *t68;
    int t69;
    unsigned int t70;
    unsigned int t71;
    char *t72;

LAB0:    t7 = (t5 + 4U);
    t8 = ((STD_STANDARD) + 96);
    t9 = (t7 + 88U);
    *((char **)t9) = t8;
    t11 = (t7 + 56U);
    *((char **)t11) = t10;
    *((unsigned char *)t10) = (unsigned char)1;
    t12 = (t7 + 80U);
    *((unsigned int *)t12) = 1U;
    t13 = (t4 + 12U);
    t14 = *((unsigned int *)t13);
    t14 = (t14 * 1U);
    t16 = (t4 + 0U);
    t17 = *((int *)t16);
    t18 = (t4 + 4U);
    t19 = *((int *)t18);
    t20 = (t4 + 8U);
    t21 = *((int *)t20);
    t22 = (t15 + 0U);
    t23 = (t22 + 0U);
    *((int *)t23) = t17;
    t23 = (t22 + 4U);
    *((int *)t23) = t19;
    t23 = (t22 + 8U);
    *((int *)t23) = t21;
    t24 = (t19 - t17);
    t25 = (t24 * t21);
    t25 = (t25 + 1);
    t23 = (t22 + 12U);
    *((unsigned int *)t23) = t25;
    t23 = (t5 + 124U);
    t26 = ((STD_STANDARD) + 1112);
    t27 = (t23 + 88U);
    *((char **)t27) = t26;
    t28 = (char *)alloca(t14);
    t29 = (t23 + 56U);
    *((char **)t29) = t28;
    xsi_type_set_default_value(t26, t28, t15);
    t30 = (t23 + 64U);
    *((char **)t30) = t15;
    t31 = (t23 + 80U);
    *((unsigned int *)t31) = t14;
    t32 = (t6 + 4U);
    t33 = (t3 != 0);
    if (t33 == 1)
        goto LAB3;

LAB2:    t34 = (t6 + 12U);
    *((char **)t34) = t4;
    t35 = (t4 + 4U);
    t36 = *((int *)t35);
    t37 = (t4 + 0U);
    t38 = *((int *)t37);
    t39 = (t36 <= t38);
    if (t39 != 0)
        goto LAB4;

LAB6:    t8 = (t4 + 0U);
    t17 = *((int *)t8);
    t9 = (t4 + 4U);
    t19 = *((int *)t9);
    t21 = t19;
    t24 = t17;

LAB18:    if (t21 >= t24)
        goto LAB19;

LAB21:
LAB5:    t8 = (t23 + 56U);
    t9 = *((char **)t8);
    t8 = (t15 + 12U);
    t14 = *((unsigned int *)t8);
    t14 = (t14 * 1U);
    t0 = xsi_get_transient_memory(t14);
    memcpy(t0, t9, t14);
    t11 = (t15 + 0U);
    t17 = *((int *)t11);
    t12 = (t15 + 4U);
    t19 = *((int *)t12);
    t13 = (t15 + 8U);
    t21 = *((int *)t13);
    t16 = (t2 + 0U);
    t18 = (t16 + 0U);
    *((int *)t18) = t17;
    t18 = (t16 + 4U);
    *((int *)t18) = t19;
    t18 = (t16 + 8U);
    *((int *)t18) = t21;
    t24 = (t19 - t17);
    t25 = (t24 * t21);
    t25 = (t25 + 1);
    t18 = (t16 + 12U);
    *((unsigned int *)t18) = t25;

LAB1:    return t0;
LAB3:    *((char **)t32) = t3;
    goto LAB2;

LAB4:    t40 = (t4 + 0U);
    t41 = *((int *)t40);
    t42 = (t4 + 4U);
    t43 = *((int *)t42);
    t44 = t43;
    t45 = t41;

LAB7:    if (t44 <= t45)
        goto LAB8;

LAB10:    goto LAB5;

LAB8:    t46 = (t7 + 56U);
    t47 = *((char **)t46);
    t48 = *((unsigned char *)t47);
    t49 = (t48 == (unsigned char)1);
    if (t49 != 0)
        goto LAB11;

LAB13:    t8 = (t4 + 0U);
    t17 = *((int *)t8);
    t9 = (t4 + 8U);
    t19 = *((int *)t9);
    t21 = (t44 - t17);
    t14 = (t21 * t19);
    t11 = (t4 + 4U);
    t24 = *((int *)t11);
    xsi_vhdl_check_range_of_index(t17, t24, t19, t44);
    t25 = (1U * t14);
    t56 = (0 + t25);
    t12 = (t3 + t56);
    t33 = *((unsigned char *)t12);
    t13 = (t23 + 56U);
    t16 = *((char **)t13);
    t13 = (t15 + 0U);
    t36 = *((int *)t13);
    t18 = (t15 + 8U);
    t38 = *((int *)t18);
    t41 = (t44 - t36);
    t57 = (t41 * t38);
    t20 = (t15 + 4U);
    t43 = *((int *)t20);
    xsi_vhdl_check_range_of_index(t36, t43, t38, t44);
    t67 = (1U * t57);
    t70 = (0 + t67);
    t22 = (t16 + t70);
    *((unsigned char *)t22) = t33;

LAB12:    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t39 = *((unsigned char *)t9);
    if (t39 == 1)
        goto LAB14;

LAB15:    t33 = (unsigned char)0;

LAB16:    t16 = (t7 + 56U);
    t18 = *((char **)t16);
    t16 = (t18 + 0);
    *((unsigned char *)t16) = t33;

LAB9:    if (t44 == t45)
        goto LAB10;

LAB17:    t17 = (t44 + 1);
    t44 = t17;
    goto LAB7;

LAB11:    t46 = (t4 + 0U);
    t50 = *((int *)t46);
    t51 = (t4 + 8U);
    t52 = *((int *)t51);
    t53 = (t44 - t50);
    t25 = (t53 * t52);
    t54 = (t4 + 4U);
    t55 = *((int *)t54);
    xsi_vhdl_check_range_of_index(t50, t55, t52, t44);
    t56 = (1U * t25);
    t57 = (0 + t56);
    t58 = (t3 + t57);
    t59 = *((unsigned char *)t58);
    t60 = (!(t59));
    t61 = (t23 + 56U);
    t62 = *((char **)t61);
    t61 = (t15 + 0U);
    t63 = *((int *)t61);
    t64 = (t15 + 8U);
    t65 = *((int *)t64);
    t66 = (t44 - t63);
    t67 = (t66 * t65);
    t68 = (t15 + 4U);
    t69 = *((int *)t68);
    xsi_vhdl_check_range_of_index(t63, t69, t65, t44);
    t70 = (1U * t67);
    t71 = (0 + t70);
    t72 = (t62 + t71);
    *((unsigned char *)t72) = t60;
    goto LAB12;

LAB14:    t8 = (t4 + 0U);
    t17 = *((int *)t8);
    t11 = (t4 + 8U);
    t19 = *((int *)t11);
    t21 = (t44 - t17);
    t14 = (t21 * t19);
    t12 = (t4 + 4U);
    t24 = *((int *)t12);
    xsi_vhdl_check_range_of_index(t17, t24, t19, t44);
    t25 = (1U * t14);
    t56 = (0 + t25);
    t13 = (t3 + t56);
    t48 = *((unsigned char *)t13);
    t33 = t48;
    goto LAB16;

LAB19:    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    t33 = *((unsigned char *)t12);
    t39 = (t33 == (unsigned char)1);
    if (t39 != 0)
        goto LAB22;

LAB24:    t8 = (t4 + 0U);
    t17 = *((int *)t8);
    t9 = (t4 + 8U);
    t19 = *((int *)t9);
    t36 = (t21 - t17);
    t14 = (t36 * t19);
    t11 = (t4 + 4U);
    t38 = *((int *)t11);
    xsi_vhdl_check_range_of_index(t17, t38, t19, t21);
    t25 = (1U * t14);
    t56 = (0 + t25);
    t12 = (t3 + t56);
    t33 = *((unsigned char *)t12);
    t13 = (t23 + 56U);
    t16 = *((char **)t13);
    t13 = (t15 + 0U);
    t41 = *((int *)t13);
    t18 = (t15 + 8U);
    t43 = *((int *)t18);
    t44 = (t21 - t41);
    t57 = (t44 * t43);
    t20 = (t15 + 4U);
    t45 = *((int *)t20);
    xsi_vhdl_check_range_of_index(t41, t45, t43, t21);
    t67 = (1U * t57);
    t70 = (0 + t67);
    t22 = (t16 + t70);
    *((unsigned char *)t22) = t33;

LAB23:    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t39 = *((unsigned char *)t9);
    if (t39 == 1)
        goto LAB25;

LAB26:    t33 = (unsigned char)0;

LAB27:    t16 = (t7 + 56U);
    t18 = *((char **)t16);
    t16 = (t18 + 0);
    *((unsigned char *)t16) = t33;

LAB20:    if (t21 == t24)
        goto LAB21;

LAB28:    t17 = (t21 + -1);
    t21 = t17;
    goto LAB18;

LAB22:    t11 = (t4 + 0U);
    t36 = *((int *)t11);
    t13 = (t4 + 8U);
    t38 = *((int *)t13);
    t41 = (t21 - t36);
    t14 = (t41 * t38);
    t16 = (t4 + 4U);
    t43 = *((int *)t16);
    xsi_vhdl_check_range_of_index(t36, t43, t38, t21);
    t25 = (1U * t14);
    t56 = (0 + t25);
    t18 = (t3 + t56);
    t48 = *((unsigned char *)t18);
    t49 = (!(t48));
    t20 = (t23 + 56U);
    t22 = *((char **)t20);
    t20 = (t15 + 0U);
    t44 = *((int *)t20);
    t26 = (t15 + 8U);
    t45 = *((int *)t26);
    t50 = (t21 - t44);
    t57 = (t50 * t45);
    t27 = (t15 + 4U);
    t52 = *((int *)t27);
    xsi_vhdl_check_range_of_index(t44, t52, t45, t21);
    t67 = (1U * t57);
    t70 = (0 + t67);
    t29 = (t22 + t70);
    *((unsigned char *)t29) = t49;
    goto LAB23;

LAB25:    t8 = (t4 + 0U);
    t17 = *((int *)t8);
    t11 = (t4 + 8U);
    t19 = *((int *)t11);
    t36 = (t21 - t17);
    t14 = (t36 * t19);
    t12 = (t4 + 4U);
    t38 = *((int *)t12);
    xsi_vhdl_check_range_of_index(t17, t38, t19, t21);
    t25 = (1U * t14);
    t56 = (0 + t25);
    t13 = (t3 + t56);
    t48 = *((unsigned char *)t13);
    t33 = t48;
    goto LAB27;

LAB29:;
}


extern void work_p_1146067867_init()
{
	static char *se[] = {(void *)work_p_1146067867_sub_4021871946_2955484629,(void *)work_p_1146067867_sub_3335567602_2955484629};
	xsi_register_didat("work_p_1146067867", "isim/BMCUtb_isim_beh.exe.sim/work/p_1146067867.didat");
	xsi_register_subprogram_executes(se);
}
